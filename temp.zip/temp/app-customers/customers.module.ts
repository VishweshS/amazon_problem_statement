import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { CustomersComponent } from './app.customers.component';
import { CustomersListComponent } from './app-customers-list/app.cutomers.list.component';



@NgModule({
    declarations: [CustomersComponent, CustomersListComponent],
    exports: [CustomersComponent]

})

export class CustomersModule{

}