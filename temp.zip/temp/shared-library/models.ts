export interface ICustomer{
    id:number;
    name:string;
    city:string;
    customerSince:Date;
    orderTotal:number;
}