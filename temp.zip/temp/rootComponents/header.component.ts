import {Component} from '@angular/core';



@Component({
selector:"app-header",
template:`
    <table width="100%">
        <tr>
            <td width="120px"><img src="../../assets/images/1.png" width="100" height="100"></td>
            <td width="*" align="center"><h2>Customers Single Page Angular Application</h2></td>
        </tr> 
    </table>   
`

})
export class HeaderComponent{


}