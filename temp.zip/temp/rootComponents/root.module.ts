import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';

import {HeaderComponent} from './header.component';
import { FooterComponent } from './footer.component';
import { MenuComponent } from './menu.component';

@NgModule({
    declarations: [HeaderComponent, FooterComponent,MenuComponent],
    exports: [HeaderComponent, FooterComponent,MenuComponent]

})

export class RootComponentsModule{

}