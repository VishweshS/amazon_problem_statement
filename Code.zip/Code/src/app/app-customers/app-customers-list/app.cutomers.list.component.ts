import {Component, Input} from '@angular/core';
import { ICustomer } from 'src/app/shared-library/models';


@Component({
    selector:"app-customers-list",
    templateUrl:"./app.customers.list.component.html"
})


export class CustomersListComponent{
    title : string = "List of Customers";
    //private backing field to store customers
    private _lstCustomers : ICustomer[] = [];
    customersOrderTotal: number;
    filterText = "xyz";
    applyFilter(event:any)
    {
        console.log(this.filterText);
    }
    //property lstCustomers to act as gettor and settor
    //Customers compoment uses this property to push the array of customers
    @Input() get lstCustomers():ICustomer[] {
        return this._lstCustomers;
    }
    set lstCustomers(value:ICustomer[]) {
        if(value){
            this._lstCustomers = value
            this.calculateOrderTotals();
        }
    }
    calculateOrderTotals(){
        this.customersOrderTotal = 0;
        this.lstCustomers.forEach((cust:ICustomer) =>{
            this.customersOrderTotal += cust.orderTotal;
        })
    }
}