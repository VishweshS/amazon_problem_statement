import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { CustomersComponent } from './app.customers.component';
import { CustomersListComponent } from './app-customers-list/app.cutomers.list.component';
import {FormsModule} from '@angular/forms'


@NgModule({
    declarations: [CustomersComponent, CustomersListComponent],
    exports: [CustomersComponent],
    imports: [CommonModule,FormsModule]

})

export class CustomersModule{

}