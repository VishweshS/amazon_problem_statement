import {Component, OnInit} from '@angular/core';
import { ICustomer } from '../shared-library/models';


@Component({
    selector : "app-customers",
    templateUrl : "./app.customers.component.html"
})
export class CustomersComponent implements OnInit{

    title : string;
    customers:ICustomer[];
    toggleText = "Show Customers List";
    isListVisible = false;
    toggleVisibility(){
        this.isListVisible = !this.isListVisible;
        if(this.isListVisible ==true){
            this.toggleText = "Hide Customers List";
        }else { this.toggleText ="Show Customers List" }
    }
    //constructor
        constructor (){
                this.title = "Initial Title Value";
        }

    //Component have a lifecycle, Init, Render, Dispose

    ngOnInit(){

        //plate to initialize the values
       this.title = "Customers List"
       //this data will later come from a REST API
       this.customers = [
        {id:201,name:"donald Trump",city:"Oregon",customerSince:new Date(2009,7,12),orderTotal:563.32},
        {id:202,name:"Angela Merkel",city:"Berlin",customerSince:new Date(2007,3,7),orderTotal:263.77},
        {id:203,name:"Emmanuel Macron",city:"Paris",customerSince:new Date(2017,3,30),orderTotal:413.32},
        {id:204,name:"Mahinda Rajapakse",city:"Colombo",customerSince:new Date(2004,4,7),orderTotal:518.55},
        {id:205,name:"Shinzo Abe",city:"Tokyo",customerSince:new Date(2016,6,22),orderTotal:712.11},
       ];


    }
}