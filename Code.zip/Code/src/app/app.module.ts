import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { RootComponentsModule } from './rootComponents/root.module';
import { CustomersModule } from './app-customers/customers.module';


@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule, RootComponentsModule, CustomersModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
