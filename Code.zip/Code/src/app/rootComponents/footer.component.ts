import {Component} from '@angular/core';



@Component({
selector:"app-footer",
template:`
    <table width="100%">
        <tr>
            <td width="300px"><h2><i>&copy; Vishwesh, 2020</i></h2></td>
            <td align="center"><h3>Products || Services || Locations </h3></td>
        </tr> 
    </table>   
`

})
export class FooterComponent{


}