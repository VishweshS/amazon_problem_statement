import {Component} from '@angular/core';



@Component({
selector:"app-menu",
template:`
    <table width="100%">
        <tr height="30px">
            <td width="120px"><a href="customers">Customers</a></td>
        </tr> 
        <tr height="30px">
            <td width="120px"><a href="orders">Orders</a></td>
        </tr> 
        <tr height="30px">
            <td width="120px"><a href="contactus">Contact Us</a></td>
        </tr> 
        <tr height="30px">
            <td width="120px"><a href="locations">Locations</a></td>
        </tr> 
    </table>   
`

})
export class MenuComponent{


}